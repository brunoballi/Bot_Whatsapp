import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Bot WhatsApp — Dashboard',
  description: 'Panel de administración del bot de WhatsApp',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
