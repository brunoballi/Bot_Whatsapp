import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    }

    const { contactId, text } = await req.json();

    if (!contactId || !text?.trim()) {
      return NextResponse.json(
        { error: 'Parámetros inválidos' },
        { status: 400 }
      );
    }

    // Validar que el contacto pertenece al tenant del usuario (RLS filtra)
    const { data: contact, error: contactErr } = await supabase
      .from('contacts')
      .select('id, wa_id, tenant_id')
      .eq('id', contactId)
      .single();

    if (contactErr || !contact) {
      return NextResponse.json(
        { error: 'Contacto no encontrado' },
        { status: 404 }
      );
    }

    // Llamar al bot internamente
    const botResponse = await fetch(
      `${process.env.BOT_INTERNAL_URL}/internal/send`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Internal-Token': process.env.BOT_INTERNAL_TOKEN!,
        },
        body: JSON.stringify({
          tenant_id: contact.tenant_id,
          contact_id: contact.id,
          wa_id: contact.wa_id,
          text,
        }),
      }
    );

    if (!botResponse.ok) {
      const err = await botResponse.text();
      return NextResponse.json(
        { error: `Bot error: ${err}` },
        { status: 502 }
      );
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('[API send-message] Error:', error);
    return NextResponse.json({ error: 'Error interno' }, { status: 500 });
  }
}
