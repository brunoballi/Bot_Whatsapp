import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Sidebar } from '@/components/sidebar';

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect('/login');

  // Verificar que el user esté vinculado a un tenant
  const { data: link } = await supabase
    .from('tenant_users')
    .select('tenant_id')
    .eq('user_id', user.id)
    .maybeSingle();

  if (!link) {
    return (
      <div className="flex min-h-screen items-center justify-center p-8">
        <p className="text-muted-foreground text-center">
          Tu usuario no está vinculado a ningún tenant. Contactá al administrador.
        </p>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar userEmail={user.email!} />
      <main className="flex-1 p-8 bg-muted/30">{children}</main>
    </div>
  );
}
