import { createClient } from '@/lib/supabase/server';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

export default async function MetricsPage() {
  const supabase = await createClient();
  const sevenDaysAgo = new Date(
    Date.now() - 7 * 24 * 60 * 60 * 1000
  ).toISOString();

  const [
    { count: totalMessages },
    { count: activeContacts },
    { data: recentLogs },
  ] = await Promise.all([
    supabase
      .from('message_logs')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', sevenDaysAgo),
    supabase
      .from('contacts')
      .select('*', { count: 'exact', head: true })
      .gte('last_seen_at', sevenDaysAgo),
    supabase
      .from('message_logs')
      .select('created_at, direction')
      .gte('created_at', sevenDaysAgo)
      .order('created_at', { ascending: false }),
  ]);

  // Agrupar por día
  const byDay = new Map<string, { inbound: number; outbound: number }>();
  recentLogs?.forEach((log) => {
    const day = log.created_at.slice(0, 10);
    const entry = byDay.get(day) ?? { inbound: 0, outbound: 0 };
    if (log.direction === 'inbound') entry.inbound++;
    else entry.outbound++;
    byDay.set(day, entry);
  });

  const dailyMetrics = Array.from(byDay.entries())
    .map(([day, counts]) => ({ day, ...counts }))
    .sort((a, b) => a.day.localeCompare(b.day));

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Métricas (últimos 7 días)</h1>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de mensajes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{totalMessages ?? 0}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Contactos activos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{activeContacts ?? 0}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Mensajes por día</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="py-2">Fecha</th>
                <th className="py-2">Entrantes</th>
                <th className="py-2">Salientes</th>
                <th className="py-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {dailyMetrics.length === 0 ? (
                <tr>
                  <td
                    colSpan={4}
                    className="py-4 text-center text-muted-foreground"
                  >
                    Sin datos aún
                  </td>
                </tr>
              ) : (
                dailyMetrics.map((m) => (
                  <tr key={m.day} className="border-b">
                    <td className="py-2">{m.day}</td>
                    <td className="py-2">{m.inbound}</td>
                    <td className="py-2">{m.outbound}</td>
                    <td className="py-2 font-medium">
                      {m.inbound + m.outbound}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
