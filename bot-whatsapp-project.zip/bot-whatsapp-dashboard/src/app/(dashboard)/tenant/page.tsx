import { createClient } from '@/lib/supabase/server';
import { TenantForm } from './tenant-form';
import { Tenant } from '@/lib/types';

export default async function TenantPage() {
  const supabase = await createClient();
  const { data } = await supabase.from('tenants').select('*').single();

  if (!data) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Configuración del bot</h1>
        <p className="text-muted-foreground">
          No se encontró ningún tenant. Creá uno desde el SQL Editor de Supabase.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-3xl font-bold">Configuración del bot</h1>
      <TenantForm tenant={data as Tenant} />
    </div>
  );
}
