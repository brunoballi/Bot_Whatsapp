'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Tenant } from '@/lib/types';

export const TenantForm = ({ tenant }: { tenant: Tenant }) => {
  const [form, setForm] = useState({
    name: tenant.name,
    meta_phone_number_id: tenant.meta_phone_number_id,
    meta_access_token: tenant.meta_access_token,
    meta_verify_token: tenant.meta_verify_token,
    is_active: tenant.is_active,
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);

    const supabase = createClient();
    const { error } = await supabase
      .from('tenants')
      .update(form)
      .eq('id', tenant.id);

    setMessage(error ? `Error: ${error.message}` : 'Guardado correctamente');
    setSaving(false);
  };

  return (
    <Card>
      <CardContent className="space-y-4 pt-6">
        <div>
          <Label>Nombre</Label>
          <Input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </div>
        <div>
          <Label>Phone Number ID (Meta)</Label>
          <Input
            value={form.meta_phone_number_id}
            onChange={(e) =>
              setForm({ ...form, meta_phone_number_id: e.target.value })
            }
          />
        </div>
        <div>
          <Label>Access Token (Meta)</Label>
          <Input
            type="password"
            value={form.meta_access_token}
            onChange={(e) =>
              setForm({ ...form, meta_access_token: e.target.value })
            }
          />
        </div>
        <div>
          <Label>Verify Token</Label>
          <Input
            value={form.meta_verify_token}
            onChange={(e) =>
              setForm({ ...form, meta_verify_token: e.target.value })
            }
          />
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="is_active"
            checked={form.is_active}
            onChange={(e) =>
              setForm({ ...form, is_active: e.target.checked })
            }
          />
          <Label htmlFor="is_active" className="mb-0">
            Bot activo
          </Label>
        </div>

        {message && (
          <p
            className={
              message.startsWith('Error')
                ? 'text-destructive text-sm'
                : 'text-green-600 text-sm'
            }
          >
            {message}
          </p>
        )}

        <Button onClick={handleSave} disabled={saving}>
          {saving ? 'Guardando...' : 'Guardar cambios'}
        </Button>
      </CardContent>
    </Card>
  );
};
