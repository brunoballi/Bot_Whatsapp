'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Contact } from '@/lib/types';

export const SendMessageForm = ({ contacts }: { contacts: Contact[] }) => {
  const [contactId, setContactId] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleSend = async () => {
    if (!contactId || !text.trim()) return;
    setSending(true);
    setFeedback(null);

    const res = await fetch('/api/send-message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contactId, text }),
    });

    const data = await res.json();
    setFeedback(res.ok ? 'Mensaje enviado ✓' : `Error: ${data.error}`);
    if (res.ok) setText('');
    setSending(false);
  };

  if (contacts.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-muted-foreground">
            No hay contactos todavía. Cuando alguien le escriba al bot, va a aparecer acá.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="space-y-4 pt-6">
        <div>
          <Label>Contacto</Label>
          <Select value={contactId} onValueChange={setContactId}>
            <SelectTrigger>
              <SelectValue placeholder="Elegí un contacto" />
            </SelectTrigger>
            <SelectContent>
              {contacts.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.profile_name ?? 'Sin nombre'} — {c.wa_id}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Mensaje</Label>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={4}
            placeholder="Escribí el mensaje..."
          />
        </div>

        {feedback && (
          <p
            className={
              feedback.startsWith('Error')
                ? 'text-destructive text-sm'
                : 'text-green-600 text-sm'
            }
          >
            {feedback}
          </p>
        )}

        <Button
          onClick={handleSend}
          disabled={sending || !contactId || !text.trim()}
        >
          {sending ? 'Enviando...' : 'Enviar mensaje'}
        </Button>
      </CardContent>
    </Card>
  );
};
