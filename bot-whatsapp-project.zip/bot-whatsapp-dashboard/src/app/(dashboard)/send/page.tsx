import { createClient } from '@/lib/supabase/server';
import { SendMessageForm } from './send-form';
import { Contact } from '@/lib/types';

export default async function SendPage() {
  const supabase = await createClient();
  const { data: contacts } = await supabase
    .from('contacts')
    .select('*')
    .order('last_seen_at', { ascending: false })
    .limit(50);

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-3xl font-bold">Enviar mensaje manual</h1>
      <SendMessageForm contacts={(contacts as Contact[]) ?? []} />
    </div>
  );
}
