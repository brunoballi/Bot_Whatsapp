// Tipos sincronizados con el bot

export interface Tenant {
  id: string;
  name: string;
  meta_phone_number_id: string;
  meta_access_token: string;
  meta_app_secret: string;
  meta_verify_token: string;
  is_active: boolean;
  config: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Contact {
  id: string;
  tenant_id: string;
  wa_id: string;
  profile_name: string | null;
  last_seen_at: string;
}

export interface MessageLog {
  id: string;
  tenant_id: string;
  contact_id: string | null;
  direction: 'inbound' | 'outbound';
  message_type: string;
  content: Record<string, unknown>;
  status: string | null;
  created_at: string;
}

export interface DailyMetric {
  day: string;
  inbound: number;
  outbound: number;
}
