'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';

const navItems = [
  { href: '/metrics', label: 'Métricas' },
  { href: '/tenant', label: 'Configuración del bot' },
  { href: '/send', label: 'Enviar mensaje' },
];

export const Sidebar = ({ userEmail }: { userEmail: string }) => {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push('/login');
    router.refresh();
  };

  return (
    <aside className="w-64 border-r bg-background p-6 flex flex-col">
      <h2 className="text-lg font-semibold mb-6">Bot WhatsApp</h2>
      <nav className="flex-1 space-y-1">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`block px-3 py-2 rounded-md text-sm transition-colors ${
              pathname === item.href
                ? 'bg-primary text-primary-foreground'
                : 'hover:bg-muted'
            }`}
          >
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="pt-6 border-t space-y-2">
        <p className="text-xs text-muted-foreground truncate">{userEmail}</p>
        <Button
          onClick={handleLogout}
          variant="outline"
          size="sm"
          className="w-full"
        >
          Cerrar sesión
        </Button>
      </div>
    </aside>
  );
};
