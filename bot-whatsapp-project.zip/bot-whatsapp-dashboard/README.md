# Dashboard — Bot WhatsApp

Panel de administración para el bot de WhatsApp.

## Stack

- Next.js 14 (App Router) + TypeScript
- Supabase Auth (email + password)
- Tailwind CSS + shadcn/ui

## Funcionalidades

- Login con Supabase Auth
- Métricas básicas (últimos 7 días)
- ABM del tenant (credenciales del bot)
- Envío manual de mensajes a contactos existentes

## Setup

```bash
npm install
cp .env.local.example .env.local
# Editar .env.local
npm run dev
```

Por defecto levanta en `http://localhost:3001`.

### Variables de entorno

| Variable | Descripción |
|----------|-------------|
| `NEXT_PUBLIC_SUPABASE_URL` | URL del proyecto Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Anon key (NO la service role) |
| `BOT_INTERNAL_URL` | URL del bot (ej. `http://localhost:3000`) |
| `BOT_INTERNAL_TOKEN` | Mismo token que configuraste en el bot |

## Primer acceso

1. Ejecutar el schema SQL en Supabase (está en `db/schema.sql` del paquete raíz).
2. En el panel de Supabase: **Authentication → Users → Add user** (email + password).
3. Vincular ese usuario con un tenant existente:

```sql
INSERT INTO public.tenant_users (user_id, tenant_id, role)
VALUES (
  'UUID_DEL_USER',       -- copiar de Authentication > Users
  'UUID_DEL_TENANT',     -- copiar de tu INSERT en tenants
  'admin'
);
```

4. `npm run dev` → abrir `http://localhost:3001` → login con ese email/password.

## Producción

```bash
npm run build
npm start
```

Recomendado: desplegar en **Vercel** y apuntar `BOT_INTERNAL_URL` a la URL interna del bot (Railway/Fly).
