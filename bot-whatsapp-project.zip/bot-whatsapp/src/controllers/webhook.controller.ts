import { Request, Response } from 'express';
import { env } from '../config/env';
import { MetaWebhookPayload, IncomingMessage } from '../types/whatsapp.types';
import { resolveTenantByPhoneNumberId } from '../services/tenant.service';
import { upsertContact } from '../services/contact.service';
import { getOrCreateSession } from '../services/session.service';
import { logInboundMessage } from '../services/log.service';
import { markAsRead } from '../services/meta.service';
import { handleIncomingMessage } from '../flows/main.flow';

// ============================================
// GET — Verificación del webhook
// ============================================
export const verifyWebhook = (req: Request, res: Response): void => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === env.meta.verifyToken) {
    console.log('[Webhook] Verificación exitosa');
    res.status(200).send(challenge);
    return;
  }

  res.status(403).json({ error: 'Token inválido' });
};

// ============================================
// POST — Mensajes entrantes
// ============================================
export const receiveMessage = async (
  req: Request,
  res: Response
): Promise<void> => {
  // ACK inmediato a Meta — evitar timeouts y reintentos
  res.status(200).send('OK');

  try {
    const payload: MetaWebhookPayload = JSON.parse(req.body.toString());
    const changes = payload.entry?.[0]?.changes?.[0]?.value;

    if (!changes) return;
    // Ignorar status updates (delivered/read/etc.)
    if (!changes.messages?.length) return;

    const phoneNumberId = changes.metadata.phone_number_id;
    const message: IncomingMessage = changes.messages[0];
    const profileName = changes.contacts?.[0]?.profile?.name ?? 'Usuario';

    // 1. Resolver tenant
    const tenant = await resolveTenantByPhoneNumberId(phoneNumberId);
    if (!tenant) {
      console.warn(`[Webhook] Mensaje descartado, tenant inexistente: ${phoneNumberId}`);
      return;
    }

    // 2. Upsert contact
    const contact = await upsertContact(tenant.id, message.from, profileName);
    if (!contact) return;

    // 3. Log inbound (fire-and-forget)
    void logInboundMessage(tenant.id, contact.id, message);

    // 4. Marcar como leído (fire-and-forget)
    void markAsRead(tenant, message.id);

    // 5. Obtener/crear sesión
    const session = await getOrCreateSession(tenant.id, contact.id);

    // 6. Delegar al flow
    await handleIncomingMessage({
      tenant,
      contact,
      session,
      message,
    });
  } catch (error) {
    console.error('[Webhook] Error procesando payload:', error);
  }
};
