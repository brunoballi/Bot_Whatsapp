import { Tenant, IncomingMessage } from '../types/whatsapp.types';
import { Contact } from '../services/contact.service';
import { Session, updateSession, resetSession } from '../services/session.service';
import { sendTextMessage, sendButtonMessage } from '../services/meta.service';

// ============================================
// Contexto unificado que recibe cada flow
// ============================================
export interface FlowContext {
  tenant: Tenant;
  contact: Contact;
  session: Session;
  message: IncomingMessage;
}

// ============================================
// Router principal
// Delega a sub-flows según session.current_flow
// ============================================
export const handleIncomingMessage = async (ctx: FlowContext): Promise<void> => {
  const { session } = ctx;

  try {
    switch (session.current_flow) {
      case 'main':
        await mainFlow(ctx);
        break;

      // case 'checkout': await checkoutFlow(ctx); break;
      // case 'support':  await supportFlow(ctx);  break;

      default:
        console.warn(`[Flow] Flow desconocido: ${session.current_flow}`);
        await resetSession(session.id);
        await mainFlow(ctx);
    }
  } catch (error) {
    console.error('[Flow] Error en handleIncomingMessage:', error);
    await sendTextMessage(
      ctx.tenant,
      ctx.contact.wa_id,
      'Ocurrió un error procesando tu mensaje. Intentá nuevamente en unos segundos.',
      ctx.contact.id
    );
  }
};

// ============================================
// Flow principal — ejemplo mínimo funcional
// ============================================
const mainFlow = async (ctx: FlowContext): Promise<void> => {
  const { tenant, contact, session, message } = ctx;
  const step = session.current_step;

  // Extraer input normalizado (texto o id de botón)
  const input =
    message.type === 'interactive'
      ? message.interactive?.button_reply?.id ??
        message.interactive?.list_reply?.id ??
        ''
      : message.text?.body?.trim().toLowerCase() ?? '';

  switch (step) {
    case 'start': {
      await sendButtonMessage(
        tenant,
        contact.wa_id,
        `Hola ${contact.profile_name ?? ''} 👋\n¿En qué te puedo ayudar?`,
        [
          { id: 'opt_info', title: 'Información' },
          { id: 'opt_support', title: 'Soporte' },
          { id: 'opt_human', title: 'Hablar con alguien' },
        ],
        contact.id
      );
      await updateSession(session.id, {
        current_step: 'waiting_main_choice',
        extendTTL: true,
      });
      break;
    }

    case 'waiting_main_choice': {
      if (input === 'opt_info') {
        await sendTextMessage(
          tenant,
          contact.wa_id,
          'Somos una empresa dedicada a... (configurar este texto).',
          contact.id
        );
        await resetSession(session.id);
      } else if (input === 'opt_support') {
        await sendTextMessage(
          tenant,
          contact.wa_id,
          'Contanos tu consulta y te respondemos a la brevedad.',
          contact.id
        );
        await updateSession(session.id, {
          current_step: 'waiting_support_message',
          extendTTL: true,
        });
      } else if (input === 'opt_human') {
        await sendTextMessage(
          tenant,
          contact.wa_id,
          'Te derivamos con un asesor. En breve te contactan.',
          contact.id
        );
        await resetSession(session.id);
      } else {
        await sendTextMessage(
          tenant,
          contact.wa_id,
          'No entendí tu respuesta. Por favor elegí una de las opciones.',
          contact.id
        );
      }
      break;
    }

    case 'waiting_support_message': {
      // Acá podrías guardar el ticket en otra tabla
      await sendTextMessage(
        tenant,
        contact.wa_id,
        '¡Gracias! Recibimos tu consulta y te respondemos pronto.',
        contact.id
      );
      await resetSession(session.id);
      break;
    }

    default:
      await resetSession(session.id);
      await mainFlow(ctx);
  }
};
