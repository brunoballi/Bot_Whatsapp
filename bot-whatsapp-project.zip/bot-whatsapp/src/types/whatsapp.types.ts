// ============================================
// Tipos de payloads entrantes desde Meta
// ============================================
export interface MetaWebhookPayload {
  object: string;
  entry: Entry[];
}

export interface Entry {
  id: string;
  changes: Change[];
}

export interface Change {
  value: ChangeValue;
  field: string;
}

export interface ChangeValue {
  messaging_product: string;
  metadata: { display_phone_number: string; phone_number_id: string };
  contacts?: Contact[];
  messages?: IncomingMessage[];
  statuses?: MessageStatus[];
}

export interface Contact {
  profile: { name: string };
  wa_id: string;
}

export interface IncomingMessage {
  from: string;
  id: string;
  timestamp: string;
  type: 'text' | 'interactive' | 'image' | 'audio' | 'document' | 'location';
  text?: { body: string };
  interactive?: {
    type: 'button_reply' | 'list_reply';
    button_reply?: { id: string; title: string };
    list_reply?: { id: string; title: string };
  };
}

export interface MessageStatus {
  id: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  timestamp: string;
  recipient_id: string;
}

// ============================================
// Tipos de dominio (multi-tenant)
// ============================================
export interface Tenant {
  id: string;
  name: string;
  meta_phone_number_id: string;
  meta_access_token: string;
  meta_app_secret: string;
  meta_verify_token: string;
  is_active: boolean;
  config: Record<string, unknown>;
}

// ============================================
// Tipos de mensajes salientes
// ============================================
export interface InteractiveButton {
  id: string;
  title: string; // max 20 chars
}

export interface ListRow {
  id: string;
  title: string; // max 24 chars
  description?: string; // max 72 chars
}

export interface ListSection {
  title: string; // max 24 chars
  rows: ListRow[]; // max 10 rows total entre todas las secciones
}

export interface MetaSendResponse {
  messaging_product: string;
  contacts: { input: string; wa_id: string }[];
  messages: { id: string }[];
}
