import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { env } from '../config/env';

export const verifyMetaSignature = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const signature = req.headers['x-hub-signature-256'] as string;

  if (!signature) {
    res.status(401).json({ error: 'Firma ausente' });
    return;
  }

  const expected = `sha256=${crypto
    .createHmac('sha256', env.meta.appSecret)
    .update(req.body) // req.body es Buffer gracias a express.raw()
    .digest('hex')}`;

  try {
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
      res.status(403).json({ error: 'Firma inválida' });
      return;
    }
  } catch {
    res.status(403).json({ error: 'Firma inválida' });
    return;
  }

  next();
};
