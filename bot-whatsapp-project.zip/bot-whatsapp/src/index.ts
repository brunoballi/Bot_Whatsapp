import express from 'express';
import { env } from './config/env';
import webhookRoutes from './routes/webhook.routes';
import internalRoutes from './routes/internal.routes';

const app = express();

// Webhook usa raw body (Buffer) para poder verificar firma HMAC
app.use('/webhook', express.raw({ type: 'application/json' }), webhookRoutes);

// Rutas internas usan JSON normal
app.use('/internal', express.json(), internalRoutes);

// Healthcheck
app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.listen(env.port, () => {
  console.log(`[Server] Corriendo en puerto ${env.port}`);
});
