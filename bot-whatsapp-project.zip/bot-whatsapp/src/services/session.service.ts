import { getSupabaseClient } from '../config/supabase';

export interface Session {
  id: string;
  tenant_id: string;
  contact_id: string;
  current_flow: string;
  current_step: string;
  context: Record<string, unknown>;
  expires_at: string;
  created_at: string;
  updated_at: string;
}

const SESSION_TTL_HOURS = 24;

// ============================================
// Recuperar sesión activa o crear una nueva
// ============================================
export const getOrCreateSession = async (
  tenantId: string,
  contactId: string
): Promise<Session> => {
  const supabase = getSupabaseClient();

  // 1. Intentar recuperar sesión no expirada
  const { data: existing } = await supabase
    .from('sessions')
    .select('*')
    .eq('tenant_id', tenantId)
    .eq('contact_id', contactId)
    .gt('expires_at', new Date().toISOString())
    .maybeSingle();

  if (existing) return existing as Session;

  // 2. Si expiró o no existe: upsert (sobrescribe la expirada gracias al UNIQUE)
  const expiresAt = new Date(
    Date.now() + SESSION_TTL_HOURS * 60 * 60 * 1000
  ).toISOString();

  const { data: created, error } = await supabase
    .from('sessions')
    .upsert(
      {
        tenant_id: tenantId,
        contact_id: contactId,
        current_flow: 'main',
        current_step: 'start',
        context: {},
        expires_at: expiresAt,
      },
      { onConflict: 'tenant_id,contact_id' }
    )
    .select()
    .single();

  if (error || !created) {
    throw new Error(`[SessionService] Error creando sesión: ${error?.message}`);
  }

  return created as Session;
};

// ============================================
// Actualizar estado de la sesión
// ============================================
export interface SessionUpdate {
  current_flow?: string;
  current_step?: string;
  context?: Record<string, unknown>;
  extendTTL?: boolean;
}

export const updateSession = async (
  sessionId: string,
  update: SessionUpdate
): Promise<void> => {
  const supabase = getSupabaseClient();

  const payload: Record<string, unknown> = {};
  if (update.current_flow !== undefined) payload.current_flow = update.current_flow;
  if (update.current_step !== undefined) payload.current_step = update.current_step;
  if (update.context !== undefined) payload.context = update.context;
  if (update.extendTTL) {
    payload.expires_at = new Date(
      Date.now() + SESSION_TTL_HOURS * 60 * 60 * 1000
    ).toISOString();
  }

  const { error } = await supabase
    .from('sessions')
    .update(payload)
    .eq('id', sessionId);

  if (error) {
    console.error('[SessionService] Error actualizando sesión:', error);
  }
};

// ============================================
// Resetear sesión al flow principal
// ============================================
export const resetSession = async (sessionId: string): Promise<void> => {
  await updateSession(sessionId, {
    current_flow: 'main',
    current_step: 'start',
    context: {},
    extendTTL: true,
  });
};
