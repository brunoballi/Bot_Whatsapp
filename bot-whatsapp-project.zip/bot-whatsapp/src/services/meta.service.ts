import axios, { AxiosError } from 'axios';
import { getSupabaseClient } from '../config/supabase';
import {
  Tenant,
  InteractiveButton,
  ListSection,
  MetaSendResponse,
} from '../types/whatsapp.types';

const META_API_VERSION = 'v21.0';
const META_BASE_URL = `https://graph.facebook.com/${META_API_VERSION}`;

// ============================================
// Helper privado: POST genérico a Meta
// ============================================
const sendToMeta = async (
  tenant: Tenant,
  payload: Record<string, unknown>
): Promise<MetaSendResponse> => {
  const url = `${META_BASE_URL}/${tenant.meta_phone_number_id}/messages`;

  try {
    const { data } = await axios.post<MetaSendResponse>(url, payload, {
      headers: {
        Authorization: `Bearer ${tenant.meta_access_token}`,
        'Content-Type': 'application/json',
      },
      timeout: 10_000,
    });
    return data;
  } catch (error) {
    const err = error as AxiosError;
    console.error('[MetaService] Error enviando mensaje:', {
      status: err.response?.status,
      data: err.response?.data,
    });
    throw new Error(`Meta API error: ${err.response?.status ?? 'unknown'}`);
  }
};

// ============================================
// Helper privado: log en message_logs
// ============================================
const logOutboundMessage = async (
  tenantId: string,
  contactId: string | null,
  waMessageId: string | null,
  messageType: string,
  content: Record<string, unknown>,
  errorMessage?: string
): Promise<void> => {
  const supabase = getSupabaseClient();
  const { error } = await supabase.from('message_logs').insert({
    tenant_id: tenantId,
    contact_id: contactId,
    wa_message_id: waMessageId,
    direction: 'outbound',
    message_type: messageType,
    content,
    status: errorMessage ? 'failed' : 'sent',
    error_message: errorMessage ?? null,
  });

  if (error) console.error('[MetaService] Error loggeando:', error);
};

// ============================================
// 1. Enviar texto plano
// ============================================
export const sendTextMessage = async (
  tenant: Tenant,
  to: string,
  body: string,
  contactId: string | null = null
): Promise<string | null> => {
  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to,
    type: 'text',
    text: { body, preview_url: false },
  };

  try {
    const response = await sendToMeta(tenant, payload);
    const waMessageId = response.messages[0]?.id ?? null;
    await logOutboundMessage(tenant.id, contactId, waMessageId, 'text', payload);
    return waMessageId;
  } catch (error) {
    const msg = (error as Error).message;
    await logOutboundMessage(tenant.id, contactId, null, 'text', payload, msg);
    return null;
  }
};

// ============================================
// 2. Enviar mensaje con botones (max 3)
// ============================================
export const sendButtonMessage = async (
  tenant: Tenant,
  to: string,
  bodyText: string,
  buttons: InteractiveButton[],
  contactId: string | null = null
): Promise<string | null> => {
  if (buttons.length === 0 || buttons.length > 3) {
    throw new Error('Meta permite entre 1 y 3 botones');
  }

  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to,
    type: 'interactive',
    interactive: {
      type: 'button',
      body: { text: bodyText },
      action: {
        buttons: buttons.map((b) => ({
          type: 'reply',
          reply: { id: b.id, title: b.title.slice(0, 20) },
        })),
      },
    },
  };

  try {
    const response = await sendToMeta(tenant, payload);
    const waMessageId = response.messages[0]?.id ?? null;
    await logOutboundMessage(
      tenant.id,
      contactId,
      waMessageId,
      'interactive_button',
      payload
    );
    return waMessageId;
  } catch (error) {
    const msg = (error as Error).message;
    await logOutboundMessage(
      tenant.id,
      contactId,
      null,
      'interactive_button',
      payload,
      msg
    );
    return null;
  }
};

// ============================================
// 3. Enviar mensaje con lista (max 10 rows)
// ============================================
export const sendListMessage = async (
  tenant: Tenant,
  to: string,
  bodyText: string,
  buttonText: string,
  sections: ListSection[],
  contactId: string | null = null
): Promise<string | null> => {
  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to,
    type: 'interactive',
    interactive: {
      type: 'list',
      body: { text: bodyText },
      action: {
        button: buttonText.slice(0, 20),
        sections,
      },
    },
  };

  try {
    const response = await sendToMeta(tenant, payload);
    const waMessageId = response.messages[0]?.id ?? null;
    await logOutboundMessage(
      tenant.id,
      contactId,
      waMessageId,
      'interactive_list',
      payload
    );
    return waMessageId;
  } catch (error) {
    const msg = (error as Error).message;
    await logOutboundMessage(
      tenant.id,
      contactId,
      null,
      'interactive_list',
      payload,
      msg
    );
    return null;
  }
};

// ============================================
// 4. Marcar mensaje entrante como leído
// ============================================
export const markAsRead = async (
  tenant: Tenant,
  waMessageId: string
): Promise<void> => {
  const payload = {
    messaging_product: 'whatsapp',
    status: 'read',
    message_id: waMessageId,
  };

  try {
    await sendToMeta(tenant, payload);
  } catch (error) {
    console.error('[MetaService] No se pudo marcar como leído:', error);
  }
};
