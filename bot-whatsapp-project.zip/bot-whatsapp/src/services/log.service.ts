import { getSupabaseClient } from '../config/supabase';
import { IncomingMessage } from '../types/whatsapp.types';

export const logInboundMessage = async (
  tenantId: string,
  contactId: string,
  message: IncomingMessage
): Promise<void> => {
  const supabase = getSupabaseClient();

  const { error } = await supabase.from('message_logs').insert({
    tenant_id: tenantId,
    contact_id: contactId,
    wa_message_id: message.id,
    direction: 'inbound',
    message_type: message.type,
    content: message as unknown as Record<string, unknown>,
  });

  if (error) console.error('[LogService] Error loggeando inbound:', error);
};
