import { getSupabaseClient } from '../config/supabase';
import { Tenant } from '../types/whatsapp.types';

// Cache en memoria (TTL 5 min) para evitar query en cada mensaje
const cache = new Map<string, { tenant: Tenant; expiresAt: number }>();
const CACHE_TTL_MS = 5 * 60 * 1000;

export const resolveTenantByPhoneNumberId = async (
  phoneNumberId: string
): Promise<Tenant | null> => {
  const cached = cache.get(phoneNumberId);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.tenant;
  }

  const supabase = getSupabaseClient();
  const { data, error } = await supabase
    .from('tenants')
    .select('*')
    .eq('meta_phone_number_id', phoneNumberId)
    .eq('is_active', true)
    .single();

  if (error || !data) {
    console.warn(`[TenantService] Tenant no encontrado: ${phoneNumberId}`);
    return null;
  }

  const tenant = data as Tenant;
  cache.set(phoneNumberId, {
    tenant,
    expiresAt: Date.now() + CACHE_TTL_MS,
  });

  return tenant;
};

export const resolveTenantById = async (
  tenantId: string
): Promise<Tenant | null> => {
  const supabase = getSupabaseClient();
  const { data, error } = await supabase
    .from('tenants')
    .select('*')
    .eq('id', tenantId)
    .eq('is_active', true)
    .single();

  if (error || !data) return null;
  return data as Tenant;
};

export const invalidateTenantCache = (phoneNumberId?: string): void => {
  if (phoneNumberId) cache.delete(phoneNumberId);
  else cache.clear();
};
