import { getSupabaseClient } from '../config/supabase';

export interface Contact {
  id: string;
  tenant_id: string;
  wa_id: string;
  profile_name: string | null;
  metadata: Record<string, unknown>;
  first_seen_at: string;
  last_seen_at: string;
}

export const upsertContact = async (
  tenantId: string,
  waId: string,
  profileName: string
): Promise<Contact | null> => {
  const supabase = getSupabaseClient();

  const { data, error } = await supabase
    .from('contacts')
    .upsert(
      {
        tenant_id: tenantId,
        wa_id: waId,
        profile_name: profileName,
        last_seen_at: new Date().toISOString(),
      },
      { onConflict: 'tenant_id,wa_id' }
    )
    .select()
    .single();

  if (error) {
    console.error('[ContactService] Error en upsert:', error);
    return null;
  }

  return data as Contact;
};
