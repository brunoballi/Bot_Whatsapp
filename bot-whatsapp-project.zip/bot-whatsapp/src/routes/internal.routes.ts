import { Router, Request, Response, NextFunction } from 'express';
import { env } from '../config/env';
import { resolveTenantById } from '../services/tenant.service';
import { sendTextMessage } from '../services/meta.service';

const router = Router();

// ============================================
// Middleware: validar token compartido con dashboard
// ============================================
const verifyInternalToken = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const token = req.headers['x-internal-token'];
  if (token !== env.internal.token) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  next();
};

// ============================================
// POST /internal/send
// Permite al dashboard enviar mensajes manuales
// ============================================
router.post('/send', verifyInternalToken, async (req: Request, res: Response) => {
  try {
    const { tenant_id, contact_id, wa_id, text } = req.body;

    if (!tenant_id || !contact_id || !wa_id || !text) {
      res.status(400).json({ error: 'Parámetros faltantes' });
      return;
    }

    const tenant = await resolveTenantById(tenant_id);
    if (!tenant) {
      res.status(404).json({ error: 'Tenant no encontrado o inactivo' });
      return;
    }

    const messageId = await sendTextMessage(tenant, wa_id, text, contact_id);

    if (!messageId) {
      res.status(502).json({ error: 'Falló envío a Meta' });
      return;
    }

    res.json({ ok: true, message_id: messageId });
  } catch (error) {
    console.error('[Internal] Error en /send:', error);
    res.status(500).json({ error: 'Error interno' });
  }
});

export default router;
