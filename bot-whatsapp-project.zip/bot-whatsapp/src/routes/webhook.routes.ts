import { Router } from 'express';
import { verifyWebhook, receiveMessage } from '../controllers/webhook.controller';
import { verifyMetaSignature } from '../middlewares/signature.middleware';

const router = Router();

router.get('/', verifyWebhook);
router.post('/', verifyMetaSignature, receiveMessage);

export default router;
