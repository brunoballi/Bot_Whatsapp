import dotenv from 'dotenv';
dotenv.config();

const requiredVars = [
  'PORT',
  'SUPABASE_URL',
  'SUPABASE_SERVICE_ROLE_KEY',
  'META_APP_SECRET',
  'META_VERIFY_TOKEN',
  'BOT_INTERNAL_TOKEN',
];

requiredVars.forEach((key) => {
  if (!process.env[key]) {
    throw new Error(`[ENV] Variable de entorno faltante: ${key}`);
  }
});

export const env = {
  port: parseInt(process.env.PORT!, 10),
  supabase: {
    url: process.env.SUPABASE_URL!,
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
  },
  meta: {
    // Único app_secret global. Si a futuro cada tenant usa su propia
    // Meta App, migrar a verificación post-parseo dentro del controller.
    appSecret: process.env.META_APP_SECRET!,
    verifyToken: process.env.META_VERIFY_TOKEN!,
  },
  internal: {
    token: process.env.BOT_INTERNAL_TOKEN!,
  },
} as const;
