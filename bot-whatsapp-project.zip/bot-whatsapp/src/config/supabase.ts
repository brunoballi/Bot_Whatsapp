import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { env } from './env';

let instance: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient => {
  if (!instance) {
    instance = createClient(env.supabase.url, env.supabase.serviceRoleKey);
  }
  return instance;
};
