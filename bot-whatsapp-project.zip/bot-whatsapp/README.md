# Bot WhatsApp — Backend

Bot transaccional multi-tenant sobre **Meta Cloud API + Node.js + TypeScript + Supabase**.

## Arquitectura

```
src/
├── config/          # env tipadas + cliente Supabase singleton
├── routes/          # /webhook (Meta) + /internal (dashboard)
├── controllers/     # manejo HTTP del webhook
├── middlewares/     # verificación de firma HMAC de Meta
├── services/        # lógica de negocio (tenant, contact, session, meta, log)
├── flows/           # árbol de conversación del bot
└── types/           # tipos compartidos
```

## Requisitos

- Node.js 18+
- Cuenta de [Supabase](https://supabase.com) con proyecto creado
- App en [Meta for Developers](https://developers.facebook.com) con WhatsApp Cloud API configurado

## Setup

```bash
npm install
cp .env.example .env
# Editar .env con tus credenciales reales
```

### Variables de entorno

| Variable | Descripción |
|----------|-------------|
| `PORT` | Puerto del servidor (ej. 3000) |
| `SUPABASE_URL` | URL del proyecto Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key (bypassa RLS) |
| `META_APP_SECRET` | App secret de Meta (para verificar firma) |
| `META_VERIFY_TOKEN` | Token arbitrario para verificación del webhook |
| `BOT_INTERNAL_TOKEN` | Token compartido con el dashboard — generar con `openssl rand -hex 32` |

## Base de datos

Ejecutar `db/schema.sql` en el SQL Editor de Supabase (está en el repo del dashboard / zip raíz).

Después, insertar manualmente el primer tenant:

```sql
INSERT INTO public.tenants (
  name,
  meta_phone_number_id,
  meta_access_token,
  meta_app_secret,
  meta_verify_token
) VALUES (
  'Mi Cliente',
  'TU_PHONE_NUMBER_ID',
  'TU_ACCESS_TOKEN',
  'TU_APP_SECRET',
  'TU_VERIFY_TOKEN'
);
```

## Desarrollo

```bash
npm run dev
```

Por defecto levanta en `http://localhost:3000`.

Para recibir webhooks de Meta necesitás exponerlo con ngrok:

```bash
ngrok http 3000
```

Configurar el webhook de Meta apuntando a:
`https://xxxxx.ngrok.io/webhook`

Con el `META_VERIFY_TOKEN` que definiste en el `.env`.

## Build y producción

```bash
npm run build
npm start
```

## Endpoints

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/webhook` | Verificación inicial del webhook (Meta) |
| POST | `/webhook` | Recepción de mensajes (Meta) |
| POST | `/internal/send` | Envío manual (dashboard) — requiere `X-Internal-Token` |
| GET | `/health` | Healthcheck |

## Flujo por defecto

El flow de ejemplo en `src/flows/main.flow.ts` muestra un menú con 3 botones:
- Información
- Soporte
- Hablar con alguien

Modificá ese archivo para adaptar el bot a tu caso de uso.
