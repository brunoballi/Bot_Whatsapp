# 🤖 Bot WhatsApp — Proyecto Completo

Plataforma multi-tenant para bots transaccionales de WhatsApp con panel de administración.

## 📦 Contenido del paquete

```
.
├── bot-whatsapp/              # Backend del bot (Express + TypeScript)
├── bot-whatsapp-dashboard/    # Panel de administración (Next.js)
├── db/
│   └── schema.sql             # Schema completo de Supabase
└── README.md                  # Este archivo
```

## 🏗️ Arquitectura

```
┌─────────────┐         ┌─────────────┐
│   Meta      │ ──POST──►   BOT       │ ──► Supabase
│ (WhatsApp)  │         │ :3000       │
└─────────────┘         └──────▲──────┘
                               │ /internal/send
                        ┌──────┴──────┐
                        │  DASHBOARD  │ ──► Supabase (anon)
                        │  :3001      │
                        └─────────────┘
```

| Componente | Puerto | Rol | Auth |
|------------|--------|-----|------|
| **Bot** | 3000 | Recibe webhooks de Meta, ejecuta flows, envía mensajes | `service_role_key` |
| **Dashboard** | 3001 | UI administrativa, métricas, envío manual | Supabase Auth + `anon_key` + RLS |
| **Supabase** | — | BD + Auth + aislamiento por tenant | — |

---

## ✅ Checklist paso a paso

### 1. Crear proyecto en Supabase
- Ir a [supabase.com](https://supabase.com) → **New Project**
- Guardar la contraseña de la BD (la vas a usar 1 vez nomás)
- En **Settings → API** copiar:
  - `Project URL` → lo usás como `SUPABASE_URL`
  - `anon public` key → lo usás en el dashboard
  - `service_role` key → lo usás en el bot (⚠️ nunca exponer al frontend)

### 2. Ejecutar el schema SQL
- En Supabase: **SQL Editor → New query**
- Copiar y pegar todo el contenido de `db/schema.sql`
- Ejecutar (botón **Run** o `Ctrl+Enter`)
- Verificar en **Table Editor** que aparezcan: `tenants`, `contacts`, `sessions`, `message_logs`, `tenant_users`

### 3. Crear app en Meta for Developers
- Ir a [developers.facebook.com](https://developers.facebook.com) → **My Apps → Create App**
- Tipo: **Business**
- En el panel de la app: **Add Product → WhatsApp → Set up**
- En **WhatsApp → API Setup** guardar:
  - `Phone Number ID`
  - `Access Token` temporal (para empezar; luego generás uno permanente)
- En **Settings → Basic** guardar:
  - `App Secret` (botón "Show")

### 4. Insertar el primer tenant
En el SQL Editor de Supabase:

```sql
INSERT INTO public.tenants (
  name,
  meta_phone_number_id,
  meta_access_token,
  meta_app_secret,
  meta_verify_token
) VALUES (
  'Mi Cliente',
  'PEGAR_PHONE_NUMBER_ID',
  'PEGAR_ACCESS_TOKEN',
  'PEGAR_APP_SECRET',
  'inventar_un_token_random'   -- lo usa Meta para verificar el webhook
);

-- Guardá el UUID del tenant que devuelve:
SELECT id, name FROM public.tenants;
```

### 5. Configurar y levantar el BOT
```bash
cd bot-whatsapp
npm install
cp .env.example .env
```

Editar `.env`:
```env
PORT=3000
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=tu-service-role-key
META_APP_SECRET=tu-app-secret-de-meta
META_VERIFY_TOKEN=el-mismo-que-pusiste-en-el-INSERT
BOT_INTERNAL_TOKEN=generar-con-openssl-rand-hex-32
```

Generar el token interno:
```bash
openssl rand -hex 32
```

Levantar:
```bash
npm run dev
```

### 6. Exponer el bot con ngrok y configurar webhook en Meta
En otra terminal:
```bash
ngrok http 3000
```

Copiar la URL HTTPS que te da ngrok (ej. `https://abc123.ngrok-free.app`).

En Meta (WhatsApp → Configuration):
- **Callback URL**: `https://abc123.ngrok-free.app/webhook`
- **Verify token**: el mismo valor que pusiste en `META_VERIFY_TOKEN`
- Hacer click en **Verify and save** — si todo está bien, el bot loguea `[Webhook] Verificación exitosa`.
- En **Webhook fields**, suscribirse a `messages`.

Probar: mandá un mensaje al número de prueba de Meta. Debería aparecer el menú con 3 botones.

### 7. Crear usuario del dashboard
En Supabase:
- **Authentication → Users → Add user → Create new user**
- Completar email y password, desmarcar "Auto confirm user" si querés recibir email (o dejarlo marcado para saltar verificación)
- Copiar el **UUID** del usuario que se crea

Vincular ese usuario al tenant (SQL Editor):
```sql
INSERT INTO public.tenant_users (user_id, tenant_id, role)
VALUES (
  'UUID_DEL_USER',
  'UUID_DEL_TENANT',
  'admin'
);
```

### 8. Levantar el DASHBOARD
```bash
cd bot-whatsapp-dashboard
npm install
cp .env.local.example .env.local
```

Editar `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu-anon-key
BOT_INTERNAL_URL=http://localhost:3000
BOT_INTERNAL_TOKEN=el-mismo-del-bot
```

Levantar:
```bash
npm run dev
```

Abrir `http://localhost:3001` → login con el email/password del paso 7.

---

## 🧪 Testing end-to-end

1. Mandar un WhatsApp al número de prueba → el bot responde con el menú.
2. En el dashboard → **Métricas**: deberías ver mensajes contados.
3. En el dashboard → **Enviar mensaje**: elegí tu contacto, escribí algo y mandá.
4. Verificá que llegue el mensaje a tu WhatsApp.

---

## 🚀 Siguientes pasos sugeridos

- **Personalizar el flow** en `bot-whatsapp/src/flows/main.flow.ts`
- **Cleanup de sesiones expiradas** (cron job o función de Supabase)
- **Historial de conversación por contacto** en el dashboard
- **Deploy**: bot en Railway/Fly, dashboard en Vercel
- **Access Token permanente** de Meta (el inicial caduca cada 24h)

---

## 📁 Estructura del código

### Bot (`bot-whatsapp/`)
```
src/
├── config/           # env + cliente Supabase singleton
├── routes/           # /webhook (Meta) + /internal (dashboard)
├── controllers/      # manejo HTTP del webhook
├── middlewares/      # verificación de firma HMAC de Meta
├── services/         # lógica de negocio (tenant, contact, session, meta, log)
├── flows/            # árbol de conversación del bot
└── types/            # tipos compartidos
```

### Dashboard (`bot-whatsapp-dashboard/`)
```
src/
├── app/
│   ├── (auth)/login/         # pantalla de login
│   ├── (dashboard)/          # área protegida
│   │   ├── metrics/          # métricas de los últimos 7 días
│   │   ├── tenant/           # ABM del bot configurado
│   │   └── send/             # envío manual de mensajes
│   └── api/send-message/     # bridge hacia el bot
├── components/
│   ├── ui/                   # primitives de shadcn/ui
│   └── sidebar.tsx
└── lib/
    ├── supabase/             # clientes browser + server + middleware
    ├── types.ts
    └── utils.ts
```

---

## 🆘 Troubleshooting

| Problema | Posible causa | Solución |
|----------|---------------|----------|
| Webhook de Meta no verifica | Token distinto en `.env` y en Meta | Chequear `META_VERIFY_TOKEN` |
| Meta da 401/403 al enviar | Access Token caducado | Generar un Access Token permanente en Meta |
| Dashboard redirige a /login infinito | Usuario no vinculado a tenant | Insertar en `tenant_users` |
| "Tenant no encontrado" en logs del bot | `phone_number_id` distinto al del INSERT | Actualizar el valor en la tabla `tenants` |
| Error de firma HMAC en logs | `META_APP_SECRET` mal configurado | Copiar de nuevo de Meta → Settings → Basic |
